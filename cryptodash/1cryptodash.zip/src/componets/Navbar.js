import './Navbar.css'

const Navbar= () => {
    return(
        <div className='navbar'>
            <h1>CRYPTO CASINO</h1>
            </div>
    ); 
}

export default Navbar;