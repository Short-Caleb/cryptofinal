import './Footer.css'

const Footer= () => {
    return(
        <div style={{height:'200px', color: 'white', backgroundColor: 'black' }}>
            <h1 style={{margin: '0', padding: '1rem'}}>Bet on Yourself, Beat the House</h1>
            </div>
    );
}
export default Footer;